"use strict";

var defaults = {
  dragThreshold: 10,
  moveThreshold: 10,
  moveSpeed: 10,
  stickyScroll: true,
  innerScroll: true,
  scrollOnLinks: false,
  sameSpeed: false,
  capSpeed: "",
  shouldCap: false,
  ctrlClick: true,
  middleClick: true
}
